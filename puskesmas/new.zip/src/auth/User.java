package auth;


public abstract class User {

    
    public static void main(String[] args) {
        System.out.println("TESs");
    }
    
}
